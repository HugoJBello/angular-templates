module.exports = {
    destinyPath:"/media/pi/PINCHO/",
    basicAuthUser:"norhug",
    basicAuthPassword:"b1234"

  };